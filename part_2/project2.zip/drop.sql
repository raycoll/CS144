/*
 * Drops all tables previously created by creat.sql
 */

DROP TABLE IF EXISTS AuctionUser ;
DROP TABLE IF EXISTS Item ;
DROP TABLE IF EXISTS Bid ;
DROP TABLE IF EXISTS ItemCategory ;
